/*
 * GPIOSensor.h
 *
 * Created: 18.04.2013 15:21:45
 *  Author: Florian
 */ 


#ifndef GPIOSENSOR_H_
#define GPIOSENSOR_H_

#include "Configuration.h"

#define SUI static unsigned int

class GPIOSensor 
{
public:
	
	SUI GPER, ODER, OVR, PVR, PUER, GFER;
	
	SUI GPIOBase;
	static unsigned char portOffsetGPIO;
	static unsigned long pin;
	
	GPIOSensor();
	~GPIOSensor();
	void init( Configuration::s_GPIOSensorConfig* thisGPIOSensorConfig_ );
	bool getValue();
	void cleanUp();
};


#endif /* GPIOSENSOR_H_ */