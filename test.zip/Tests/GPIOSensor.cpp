#include "GPIOSensor.h"
#include "Configuration.h"
#include "bitmacros.h"

#define UI unsigned int
#define VUI *(volatile unsigned int*)

UI GPIOSensor::GPIOBase = 0xFFFF100;
UI GPIOSensor::GPER, GPIOSensor::ODER, GPIOSensor::OVR, GPIOSensor::PVR, GPIOSensor::PUER, GPIOSensor::GFER;
unsigned char GPIOSensor::portOffsetGPIO;
unsigned long GPIOSensor::pin;

GPIOSensor::GPIOSensor() 
//Erstelle zun�chst ein Objekt der Klasse Configuration. Rufe die Initialisierungsfunktion auf, um die korrekten Werte auslesen zu k�nnen.
//Lese GPIO-Sensor-Variablen aus der Configuration in Attribute der GPIOSensor-Klasse ein.
{
	GPER = GPIOSensor::GPIOBase + 0x00; //GPIO Enable Register (Read/Write)
	ODER = GPIOSensor::GPIOBase + 0x40; //Output Driver Enable Register (Read/Write)
	OVR = GPIOSensor::GPIOBase + 0x50; //Output Value Register (Read/Write)
	PVR = GPIOSensor::GPIOBase + 0x60; //Pin Value Register (Read)
	PUER = GPIOSensor::GPIOBase + 0x70; //Pull-up Enable Register (Read/Write)
	GFER = GPIOSensor::GPIOBase + 0xC0; //Glitch Filter Enable Register (Read/Write)
}

GPIOSensor::~GPIOSensor() 
{
	GPIOSensor::cleanUp();
}

void GPIOSensor::init( Configuration::s_GPIOSensorConfig* thisGPIOSensorConfig_ ) 
//�bernehme die �bergabewerte aus der �bergebenen s_GPIOSensorConfig und weise sie Variablen zu. Stelle sicher, dass Pin nicht als Output 
//geschaltet ist und kontrolliere ihn �ber GPIO. Entprelle den Pin durch Setzen des entsprechenden Bits im Glitch-Filter-Enable-Register.
//Wenn der Pullup-Widerstand aktiviert werden soll, dann setze das entsprechende Bit im Pullup-Enable Register.
{
	unsigned char portGPIO = thisGPIOSensorConfig_->port;
	GPIOSensor::pin = thisGPIOSensorConfig_->pin;
	bool pullUpEnabled = thisGPIOSensorConfig_->pullupEnabled;
	
	//Initialisiere Pin als Eingang
	GPIOSensor::portOffsetGPIO = (0x0100 * portGPIO);
	CLEAR_BIT(VUI (GPIOSensor::ODER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
	SET_BIT(VUI (GPIOSensor::GPER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin); //Setze GPER Bit "pin"
	SET_BIT(VUI (GPIOSensor::GFER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
	
	if(pullUpEnabled)
	{
		SET_BIT(VUI (GPIOSensor::PUER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
	}
	
}

bool GPIOSensor::getValue() 
//Wenn das Bit an der �bergebenen Pin Variable gesetzt ist, geben 'true' zur�ck ist, sonst 'false'
{
	if(VUI (GPIOSensor::PVR+GPIOSensor::portOffsetGPIO) & GPIOSensor::pin )
	{
		return true;
	}
	return false;
}
	
void GPIOSensor::cleanUp() 
//Setze gesetzte Bits zur�ck.
{
	CLEAR_BIT(VUI (GPIOSensor::PUER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
	CLEAR_BIT(VUI (GPIOSensor::GPER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
	VUI (GPIOSensor::GPER+GPIOSensor::portOffsetGPIO) & 0xFFFFFFFF;
	CLEAR_BIT(VUI (GPIOSensor::GFER+GPIOSensor::portOffsetGPIO),GPIOSensor::pin);
}