/* 
* Timer.cpp
*
* Created: 14.11.2014 16:16:57
* Author: Jonas
*/

#include "Timer.h"
#include "Configuration.h"
#include "bitmacros.h"

#define UI unsigned int
#define VUI *(volatile unsigned int*)

	UI Timer::sysclock, Timer::timerChannel, Timer::timerClock; //Systemtakt, Timerkanal und Taktquelle des Timers, werden aus der Configuration.h ausgelesen
	
	UI Timer::timerChannelOffset; //Abstraktion des vom Timerkanal abh�ngigen Offsets
	
	UI Timer::timerCCR, Timer::timerCMR, Timer::timerCV, Timer::timerRC, Timer::timerSR, Timer::timerIER, Timer::timerIDR, Timer::timerIMR; //Adressen der einzelnen Register, die f�r den Timer relevant sind

	UI Timer::timerBASE = 0xFFFF3800; //Basisadresse des Timers
	
Timer::Timer()
{
	sysclock = Configuration::CPUCLK;
	timerChannel = Configuration::Timer_Channel;
	timerClock = Configuration::Timer_Clock_Connection;
	timerChannelOffset = (Configuration::Timer_Channel*0x40);

	timerCCR = (timerBASE + 0x00 + timerChannelOffset);
	timerCMR = (timerBASE + 0x04 + timerChannelOffset);
	timerCV = (timerBASE + 0x10 + timerChannelOffset);
	timerRC = (timerBASE + 0x1C + timerChannelOffset);
	timerSR = (timerBASE + 0x20 + timerChannelOffset);
	timerIER = (timerBASE + 0x24 + timerChannelOffset);
	timerIDR = (timerBASE + 0x28 + timerChannelOffset);
	timerIMR = (timerBASE + 0x2C + timerChannelOffset);

}
Timer::~Timer()
{
	Timer::cleanUp();
} 

bool Timer::prepareTimer(unsigned long frequency)
//Schreibe den Grenzwert f�r den RC Compare in Register C und schreibe die Taktquelle in die Clock Selection Bits des CMR.
{
	int RClimit = (Timer::sysclock/(8*frequency));
	SET_BITS(VUI Timer::timerCMR, Timer::timerClock);
	VUI Timer::timerRC = RClimit;
	return true;
}

void Timer::cleanUpTimer()
//Rufe setIsTimerEnabled(false) auf, um den Timer zu deaktivieren. Rufe setIsTimerInterruptEnabled(false) auf um Timer Interrupts zu deaktivieren. 
//Setze Register C auf 0 zur�ck.
{
	Timer::setIsTimerEnabled(false);
	Timer::setIsTimerInterruptEnabled(false);
	VUI Timer::timerRC &= 0x00000000;
}

bool Timer::initTimer(unsigned long frequency)
//Aktiviere Waveform Mode (Setze Wave Bit in CMR). �berpr�fe, ob frequency ungleich 0 ist. Wenn ja, rufe "prepareTimer" auf, stelle sicher, dass CPCDIS 
//und CPCSTOP nicht gesetzt sind und setze Wavemode-Selection in CMR auf "Upmode with automatic trigger on RC Compare" (WAVSEL = 2). 
//Sonst rufe setIsTimerInterruptEnabled(false) auf und stoppe & deaktiviere Counter Clock mit dem n�chstem RC Compare (ebenfalls in CMR)
{
	SET_BIT(VUI Timer::timerCMR,15);
		
	if (frequency != 0)
	{
		Timer::prepareTimer(frequency);
		CLEAR_BIT(VUI Timer::timerCMR,6);
		CLEAR_BIT(VUI Timer::timerCMR,7);
		SET_BIT(VUI Timer::timerCMR,14);
		Timer::setIsTimerInterruptEnabled(true);
		return true;
	}
	
	SET_BIT(VUI Timer::timerCMR,6);
	SET_BIT(VUI Timer::timerCMR,7);
	Timer::setIsTimerInterruptEnabled(false);
	return false;
}

void Timer::setIsTimerEnabled(bool enabled)
//Wenn "enabled == true", setze CLKEN (Clock Enable), SWTRG (Software-Trigger) im CCR und setzte Timer::timerEnabled auf true. 
//Sonst stoppe & deaktiviere Counter Clock und setzte Timer::timerEnabled auf false.
{
	if (enabled == true)
	{
		SET_BIT(VUI Timer::timerCCR,0);
		SET_BIT(VUI Timer::timerCCR,2);
		Timer::timerEnabled = true;
	}
	else
	{
		SET_BIT(VUI Timer::timerCCR,1);
		Timer::timerEnabled = false;
	}
}

void Timer::setIsTimerInterruptEnabled(bool enabled) 
//Wenn "enabled == true", dann setze CPCS Bit in Interrupt-Enable-Register. Sonst setzte CPCS Bit in Interrupt-Disable-Register.
{
	if (enabled == true)
	{
		SET_BIT(VUI Timer::timerIER,4);
	}
	else
	{
		SET_BIT(VUI Timer::timerIDR,4);
	}
}

void Timer::resetInterruptFlag() 
//Lese das CPCS Bit des Interrupt-Status-Registers aus, um dieses zu reseten.
{
	BIT_IS_SET(VUI Timer::timerSR,4);
}

bool Timer::getIsTimerEnabled() 
//�berpr�fe, ob Counter Value ungleich null ist. Wenn ja, gebe true zur�ck, sonst false.
{
	return Timer::timerEnabled;
}

bool Timer::getIsTimerInterruptEnabled() 
//�berpr�fe, ob RC-Interrupt stattgefunden hat: Wenn CPCS Bit des Interrupt Mask Registers gesetzt ist gebe "true" zur�ck, sonst "false".
{
	if (VUI Timer::timerIMR & 0x00000010)
	{
		return true;
	}
	return false;
}

void Timer::cleanUp()
//Rufe cleanUpTimer auf und deaktiviere Takt durch setzen des CLKDIS Bits in CCR
{
	Timer::cleanUpTimer();
	SET_BIT(VUI Timer::timerCCR,1);
}