/* 
* Timer.h
*
* Created: 14.11.2014 16:16:57
* Author: Jonas
*/

#ifndef __TIMER_H__
#define __TIMER_H__
#define SUI static unsigned int
#define UI unsigned int

class Timer
{
public:
	SUI sysclock;
	SUI timerChannel; 
	SUI timerClock;
	SUI timerChannelOffset;

	SUI timerBASE;
	SUI timerCCR;
	SUI timerCMR;
	SUI timerCV;
	SUI timerRC;
	SUI timerSR;
	SUI timerIER;
	SUI timerIDR;
	SUI timerIMR;
	
	bool timerEnabled;

public:
	Timer();
	~Timer();
	
	//Folgende Kommentare sind aus der vorgegebenen Klassenbeschreibung entnommen...
	
	bool prepareTimer(unsigned long frequency); //Initialisiert einen Kanal des Timers f�r den Interrupt. �bergabewert ist die Frequenz in Hz mit der ein Interrupt geworfen wird.
	void cleanUpTimer(); //Resetet den Timer und setzt ihn auf seine default Werte zur�ck.
	bool initTimer(unsigned long frequency); //Initialisiert den Timer. Wenn die Initialisierung erfolgreich war, werden die Interrupts aktiviert. Wenn Initialisierung nicht erfolgreich war, werden Interrupts deaktiviert. �bergabewert ist die Frequenz des Timers.
	void setIsTimerEnabled(bool enabled); //Aktiviert oder deaktiviert den Timer.
	void setIsTimerInterruptEnabled(bool enabled); //Aktiviert oder deaktiviert die Interrupts die durch den Timer geworfen werden m�ssen.
	static void resetInterruptFlag(); //Liest das Interrupt-Statusregister um den Interrupt zur�ckzusetzen.
	bool getIsTimerEnabled(); //Gibt true zur�ck, wenn Timer aktiviert ist.
	bool getIsTimerInterruptEnabled(); //Gibt true zur�ck, wenn Interrupts aktiviert sind.
	void cleanUp(); //Wird vom Destruktor genutzt, um Ausgangspins zu deaktivieren und Variablen zu l�schen.
};

#endif //__TIMER_H__
